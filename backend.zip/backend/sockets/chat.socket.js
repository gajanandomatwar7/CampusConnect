const messageModel = require("../models/message.db");
const userSocketMap = {};

const chatSocket = (io) => {
    io.on("connection", async (socket) => {
        console.log("conneced socket");
        console.log("AUTH:", socket.handshake.auth);

        const { userId, userType} = socket.handshake.auth;

        if (!userId || !userType) {
            console.log("issue");
            socket.disconnect(true);
            return;
        }

        const userKey = `${userType}_${userId}`;

        userSocketMap[userKey] = socket.id;

        console.log("user connected:", userKey, socket.id);


        // const pendingMessages = await messageModel.find({
        //     receiverId: receiverId,
        //     receiverType: receiverType,
        //     delivered: false,
        // });

        // for (const msg of pendingMessages) {
        //     socket.emit("receiveMessage", {
        //         senderId: msg.senderId,
        //         senderType: msg.senderType,
        //         message: msg.message,
        //     });
        // }

        // await messageModel.updateMany(
        //     {
        //         receiverId: receiverId,
        //         receiverType: receiverType,
        //         delivered: false,
        //     },
        //     { $set: { delivered: true } }
        // );


        socket.on("privateMessage", async ({ receiverId, receiverType, message }) => {
            console.log(message);
            

            const receiverKey = `${receiverType}_${receiverId}`;
            const receiverSocketId = userSocketMap[receiverKey];
            console.log(receiverKey);
            
            // let delivered = false;

            if (receiverSocketId) {
                io.to(receiverSocketId).emit("receiveMessage", {
                    senderId: userId,
                    senderType: userType,
                    message,
                });
                // delivered = true;
            }

            // await messageModel.create({
            //     senderId: userId,
            //     senderType: userType,
            //     receiverId,
            //     receiverType,
            //     message,
            //     delivered:true
            // });
        });


        socket.on("disconnect", () => {
            delete userSocketMap[userKey];
            console.log("user disconnected:", userKey);
        });
    });
};

module.exports = chatSocket;
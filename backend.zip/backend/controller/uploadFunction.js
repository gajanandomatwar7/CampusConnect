const multer = require('multer');
const storage = multer.memoryStorage();
const uploadProfilePic=require('./uploadImage');

const upload = multer({

    storage,
    limits: { fileSize: 2 * 1024 * 1024 }, // 2MB max size, if exceed then fails the upload, meed to add a watning page as well or not accepting the upload from forntend only 
    fileFilter: (req, file, cb) => {
        const allowed = ["image/jpeg", "image/png", "image/webp"];
        if (allowed.includes(file.mimetype)) cb(null, true);
        else cb(new Error("Only JPG, PNG, WEBP allowed"), false);
    },
    
});
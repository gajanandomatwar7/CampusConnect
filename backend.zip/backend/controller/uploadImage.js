const cloudinary=require('../config/cloudinary.config');
const Student=require('../models/student.db');

const uploadStudentImage=async (req,res)=>{

};

module.exports=uploadStudentImage;
